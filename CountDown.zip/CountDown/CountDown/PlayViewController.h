//
//  PlayViewController.h
//  CountDown
//
//  Created by Henry Harris on 4/22/14.
//  Copyright (c) 2014 Dummy Code. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *beginner;
@property (weak, nonatomic) IBOutlet UIButton *intermediate;
@property (weak, nonatomic) IBOutlet UIButton *expert;

@end
