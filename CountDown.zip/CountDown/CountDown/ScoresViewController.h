//
//  ScoresViewController.h
//  CountDown
//
//  Created by Henry Harris on 4/22/14.
//  Copyright (c) 2014 Dummy Code. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScoresViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *beginner;
@property (weak, nonatomic) IBOutlet UILabel *intermediate;
@property (weak, nonatomic) IBOutlet UILabel *expert;

@end
